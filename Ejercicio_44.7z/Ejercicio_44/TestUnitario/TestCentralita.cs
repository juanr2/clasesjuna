﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CentralitaHerencia;

namespace TestUnitario
{
    [TestClass]
    public class TestCentralita
    {
        [TestMethod]
        public void ValidaLista()
        {
            Centralita c = new Centralita();
            Assert.AreNotEqual(c.Llamadas,null);
        }


        [TestMethod]
        public void ComparaLlamadas()
        {   
            //creo 2 llamadas locales y 2 provinciales con el mismo origen y destino
            Local l1 = new Local(30, "Bernal", "Bernal", 2.65f);
            Provincial l2 = new Provincial(21, "Bernal", "Bernal", Franja.Franja_1);
            Local l3 = new Local(45, "Bernal", "Bernal", 1.99f);
            //Local l3 = new Local(30, "Bernal", "Bernal", 2.65f);
            Provincial l4 = new Provincial(21, "Bernal", "Bernal", Franja.Franja_1);


            Assert.AreEqual(l1,l3);
        }
    }
}
