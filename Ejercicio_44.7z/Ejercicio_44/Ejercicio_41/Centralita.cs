﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        private string razonSocial;

        public float GananciasPorLocal
        {
            get
            {
                if (listaDeLlamadas == null) return 0;

                float result = 0;

                foreach (Llamada item in listaDeLlamadas)
                {
                    if (item is Local)
                    {
                        result += ((Local)item).CostoLlamada;
                    }
                }

                return result;
            }
        }

        public float GananciasPorProvincial
        {
            get
            {
                if (listaDeLlamadas == null) return 0;

                float result = 0;

                foreach (Llamada item in listaDeLlamadas)
                {
                    if (item is Provincial)
                    {
                        result += ((Provincial)item).CostoLlamada;
                    }
                }

                return result;
            }
        }

        public float GananciasPorTotal
        {
            get
            {
                return GananciasPorLocal + GananciasPorProvincial;
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return listaDeLlamadas;
            }
        }

        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            this.listaDeLlamadas.Add(nuevaLlamada);
        
        }


        public Centralita()
        {
           listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string nombreEmpresa)
            : this()
        {
            this.razonSocial = nombreEmpresa;
        }

        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("La razon social es: ");
            sb.AppendLine(this.razonSocial.ToString());
            sb.Append("La ganancia total es: ");
            sb.AppendLine(this.GananciasPorTotal.ToString());
            sb.Append("La ganancia por local es: ");
            sb.AppendLine(this.GananciasPorLocal.ToString());
            sb.Append("La ganancia por provincial: ");
            sb.AppendLine(this.GananciasPorProvincial.ToString());
            //sb.Append("El detalle  es: ");
            //sb.AppendLine(det.ToString());

            return sb.ToString();
        }

        public void OrdenarLlamadas()
        {
            listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }

        private float CalcularGanancia(TipoLlamada tipo)
        {
            float result;

            switch (tipo)
            {
                case TipoLlamada.Local:
                    result = GananciasPorLocal;
                    break;
                case TipoLlamada.Provincial:
                    result = GananciasPorProvincial;
                    break;
                default:
                    result = GananciasPorTotal;
                    break;
            }

            return result;
        }

        public static bool operator==(Centralita c, Llamada llamada)
        {
            return c.listaDeLlamadas.Contains(llamada);
        }

        public static bool operator !=(Centralita c, Llamada llamada)
        {
            return !c.listaDeLlamadas.Contains(llamada);

        }
        public  static Centralita operator +(Centralita c, Llamada nuevaLlamada)
        {
            if (c != nuevaLlamada)
            {
                c.AgregarLlamada(nuevaLlamada);
                

            }
            else 
            {

                throw new CentralitaException("Error", "centralita", "operator+");
            
            }
            return c;
        }
    }
}
