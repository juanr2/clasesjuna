﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
   public class Llamada
    {
        //ATRIBUTOS
        protected float _duracion;
        protected string _nroDestino;
        protected string _nroOrigen;
        protected float _costoDeLlamada;

        //PROPERTIES

        public float CostoDeLlamada
        {
            get
            {
                return _costoDeLlamada;
            }
        }
        public float Duracion
        {
            get
            {
                return _duracion;
            }
        }

        public string NroDestino
        {
            get
            {
                return _nroDestino;
            }
        }

        public string NroOrigen
        {
            get
            {
                return _nroOrigen;
            }
        }

        //METHODS

        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            _duracion = duracion;
            this._nroDestino = nroDestino;
            this._nroOrigen = nroOrigen;
        }

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("La duracion es: ");
            sb.AppendLine(_duracion.ToString());
            sb.Append("El numero de destino es: ");
            sb.AppendLine(_nroDestino.ToString());
            sb.Append("El numero de origen es: ");
            sb.AppendLine(_nroOrigen.ToString());
            sb.AppendLine(" ".ToString());

            return sb.ToString();
        }

        public static int OrdenarPorDuracion(Llamada llamada1, Llamada llamada2)
        {
            if (llamada1.Duracion < llamada2.Duracion)
                return -1;
            if (llamada1.Duracion > llamada2.Duracion)
                return 1;

            return 0;

        }

    }
}
