﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float _costo;

        public float CostoLlamada
        {
            get
            {
                return this.CalcularCosto();

            }
        }

        public Local(Llamada llamada, float costo)
            : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this._costo = costo;
        }

        public Local(float duracion, string origen, string destino, float costo)
            : base(duracion, origen, destino)
        {
            this._costo = costo;
        }

        private float CalcularCosto()
        {
            return Duracion * this._costo;

        }

        public override string Mostrar()
        {

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.Append("El costo de la llamada es: ");
            sb.AppendLine(CostoLlamada.ToString());

            return sb.ToString();
        }
    }
}
