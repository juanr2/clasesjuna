﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        protected Franja _franjaHoraria;

        public float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }

        private float CalcularCosto()
        {
            if (_franjaHoraria == Franja.Franja_1) return (1 * Duracion);
            if (_franjaHoraria == Franja.Franja_2) return (2 * Duracion);
            return (3 * Duracion);
        }

        public override string Mostrar()
        {

            StringBuilder sb = new StringBuilder();
            sb.AppendLine(base.Mostrar());
            sb.Append("El costo de la llamada es: ");
            sb.AppendLine(CostoLlamada.ToString());
            sb.Append("La franja horaria es: ");
            sb.AppendLine(_franjaHoraria.ToString());

            return sb.ToString();
        }

        public Provincial(Franja miFranja, Llamada llamada)
            : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this._franjaHoraria = miFranja;
        }

        public Provincial(float duracion, string destino, string origen, Franja miFranja)
            : base(duracion, destino, origen)
        {
            this._franjaHoraria = miFranja;
        }


    }
}
