﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia

{
    public enum Franja
    {
        Franja_1 = 1,
        Franja_2 = 2,
        Franja_3 = 3,
    }
}
